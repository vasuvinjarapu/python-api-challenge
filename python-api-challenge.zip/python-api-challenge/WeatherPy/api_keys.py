# OpenWeatherMap API Key
weather_api_key = "c3e493e7ea42f80b4a5a22a0baea25b7"

# Google API Key
g_key = "AIzaSyAHMGXPnoXJ6LfLx2QI4KXXv-ThizPTNYs"
