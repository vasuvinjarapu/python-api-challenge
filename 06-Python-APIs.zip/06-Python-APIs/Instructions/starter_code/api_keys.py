# OpenWeatherMap API Key
weather_api_key = "YOUR KEY HERE!"

# Google API Key
g_key = "YOUR KEY HERE!"
